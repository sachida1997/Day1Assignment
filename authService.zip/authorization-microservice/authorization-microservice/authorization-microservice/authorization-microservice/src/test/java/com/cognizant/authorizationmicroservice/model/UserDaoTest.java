//package com.cognizant.authorizationmicroservice.model;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//public class UserDaoTest {
//	
//	private UserDao user1;
//	private UserDao user2;
//	
//	@BeforeEach
//	void setUp() throws Exception
//	{
//		user1 = new User();
//		user2 = new User(1, "user", "pass");
//		
//	}
//
//	@Test
//	void testPensionerBean()
//	{
//		final BeanTester beanTester = new BeanTester();
//		beanTester.getFactory(Collections();
//		beanTester.testBean(User.class);
//	}
//}
