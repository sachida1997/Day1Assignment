import { Component, OnInit } from '@angular/core';
import { Todo } from '../models/Todo';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  public todoList: Todo[] = [];
  constructor() { }

  ngOnInit() {
  }

  onAddTodo(todoText: any) {
    if (todoText.trim().length === 0) {
      return;
    }
    let maxId = this.todoList.length > 0 ? Math.max(...this.todoList.map(todo => todo.todoId)) : 0;
    this.todoList.push({todoId: maxId + 1, text: todoText, isCompleted: false});
  }

  onClearTodos() {
    this.todoList = [];
  }

  onCompletingTodo(todo: Todo) {
    let index = this.todoList.findIndex(t => t.todoId === todo.todoId);
    if (index !== -1) {
      this.todoList[index].isCompleted = !this.todoList[index].isCompleted;
    }
  }

  onDeletingTodo(todoId:any) {
    this.todoList = this.todoList.filter(todo => todo.todoId !== todoId);
  }
}
