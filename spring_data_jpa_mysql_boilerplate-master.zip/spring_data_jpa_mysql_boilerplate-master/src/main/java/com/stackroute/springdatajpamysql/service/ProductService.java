package com.stackroute.springdatajpamysql.service;

import com.stackroute.springdatajpamysql.entity.Product;

import java.util.List;

//Create service interface here
public interface ProductService {
    //Add abstract methods here
    List<Product> getAllProducts();
    List<Product> getAllProductsHavingPriceLessThan(double price);

    Product getProductById(long id);
    Product saveProduct(Product product);
    String deleteProduct(long id);

    Product updateProduct(Product product, long id);

}
