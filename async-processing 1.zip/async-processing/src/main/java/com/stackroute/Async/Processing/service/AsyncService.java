package com.stackroute.Async.Processing.service;

public interface AsyncService {

    void performAsyncTask();
}
