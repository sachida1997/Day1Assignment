import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {
  
  userId!: number;
  user: any;

  // inject required user service and activated route
  constructor(private route: ActivatedRoute, private userService: UserService) {}

  //subscribe to the route params to get the id and then call the getUserById method of the UserService to get the user details
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.userId = +params['id']; // Convert to number if needed
      this.fetchUserDetails();
    });
  }

  fetchUserDetails() {
    this.userService.getUserById(this.userId)
      .subscribe((data: any) => {
        this.user = data;
      });
  }
}
