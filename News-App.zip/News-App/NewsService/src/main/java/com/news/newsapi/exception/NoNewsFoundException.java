package com.news.newsapi.exception;

public class NoNewsFoundException extends Exception {
	public NoNewsFoundException(String message) {
        super(message);
    }
}
