package com.news.newsapi.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.news.newsapi.domain.News;

@Service
public class ApiServiceImpl implements ApiService {

	
	 String API_KEY="35434c4ba91547fd996beaae378c7fef";

	@Override
	public News getNewsApi() {
		String url = "https://newsapi.org/v2/everything?q=keyword&pageSize=25&apiKey="+API_KEY;
		RestTemplate restTemplate = new RestTemplate();
		return restTemplate.getForObject(url, News.class);

	}

	@Override
	public News getNewsSearchApi(String keyword) {

		String url = "https://newsapi.org/v2/everything?q="+keyword+"&sortBy=publishedAt&pageSize=25&apiKey="+API_KEY;

		RestTemplate restTemplate = new RestTemplate();
		return restTemplate.getForObject(url, News.class);
	}

}
