package com.news.wishlist.service;

import java.util.List;

import com.news.wishlist.domain.News;
import com.news.wishlist.exception.NewsAlreadyExistsException;
import com.news.wishlist.exception.NewsNotFoundException;



public interface NewsService 
{
	boolean saveNews(News news) throws NewsAlreadyExistsException;
	
	boolean deleteNewsById(int id) throws NewsNotFoundException;
	
	List<News> getNews(String userId) throws NewsNotFoundException;
}
