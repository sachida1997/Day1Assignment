package com.news.wishlist.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.news.wishlist.domain.News;
import com.news.wishlist.exception.NewsAlreadyExistsException;
import com.news.wishlist.exception.NewsNotFoundException;
import com.news.wishlist.service.NewsService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(path = "/api/news")
public class NewsController {

	@Autowired
	private NewsService newsService;

	@PostMapping
	public ResponseEntity<?> saveNews(@RequestBody News news) {

		ResponseEntity<?> responseEntity;
		try {
			newsService.saveNews(news);
			responseEntity = new ResponseEntity<News>(news, HttpStatus.CREATED);
		} catch (NewsAlreadyExistsException e) {
			responseEntity = new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
		}
		return responseEntity;
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteNews(@PathVariable int id) {
		ResponseEntity<?> responseEntity;
		try {
			newsService.deleteNewsById(id);
			responseEntity = new ResponseEntity<String>("News deleted successfully!", HttpStatus.OK);
		} catch (NewsNotFoundException e) {
			responseEntity = new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}

		return responseEntity;
	}

	@GetMapping("/get/{userId}")
	public ResponseEntity<?> getMyFavouriteNews(@PathVariable String userId) {
		ResponseEntity<?> responseEntity;
		try {
			List<News> newsList = newsService.getNews(userId);

			responseEntity = new ResponseEntity<List<News>>(newsList, HttpStatus.OK);
		} catch (NewsNotFoundException e) {
			responseEntity = new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}
}
