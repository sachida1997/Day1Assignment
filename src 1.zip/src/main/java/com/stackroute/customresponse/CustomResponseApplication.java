package com.stackroute.customresponse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomResponseApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomResponseApplication.class, args);
	}

}
