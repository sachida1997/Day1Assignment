/**
 * 
 */
package com.cognizant9.UserProfileService.service;

import java.util.List;
import java.util.Set;

import com.cognizant9.UserProfileService.entity.UserDetails;

/**
 * @author mohit
 *
 */
public interface UserService {
	public void initRolesAndUser();
	
	public UserDetails registerNewUser(UserDetails user);

	/**
	 * @param userName
	 * @return
	 */
	public UserDetails getUserByUserName(String userName);

	/**
	 * @return
	 */
	public List<UserDetails> getAllUsers();
}
