/**
 * 
 */
package com.cognizant9.UserProfileService.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant9.UserProfileService.entity.Role;
import com.cognizant9.UserProfileService.entity.UserDetails;
import com.cognizant9.UserProfileService.kafka.Producer;
import com.cognizant9.UserProfileService.repository.RoleRepository;
import com.cognizant9.UserProfileService.repository.UserRepository;

/**
 * @author mohit
 *
 */

@Service
public class UserServiceImpl implements UserService{
	
	
	private final Producer userProfileProducer;
  

    @Autowired
    public UserServiceImpl(Producer userProfileProducer) {
        this.userProfileProducer = userProfileProducer;
    }

	@Autowired
	private UserRepository userdao;
	
	@Autowired
	private RoleRepository roleDao;
	
	@Autowired
    private PasswordEncoder passwordEncoder;
  
	 
	@Override
	public void initRolesAndUser() {
		
		Role adminRole=new Role();
		adminRole.setRoleId("4");
		adminRole.setRoleName("Admin");
		adminRole.setRoleDesc("Admin Role");
		roleDao.save(adminRole);
		
		Role userRole=new Role();
		userRole.setRoleId("3");
		userRole.setRoleName("User");
		userRole.setRoleDesc("Default Role for user");
		roleDao.save(userRole);
		
		UserDetails adminUser=new UserDetails();
		adminUser.setUserFirstName("admin");
		adminUser.setUserLastName("admin");
		adminUser.setUserName("admin123");
		adminUser.setUserPassword(getEncodedPassword("admin@pass"));
		adminUser.setContactNumber("9876543210");
		Set<Role> adminRoles=new HashSet<>();
		adminRoles.add(adminRole);
		adminUser.setRole(adminRoles);
		userdao.save(adminUser);
		
		
		
//		User user=new User();
//		user.setUserFirstName("mohit");
//		user.setUserLastName("sahu");
//		user.setUserName("mohit123");
//		user.setUserPassword(getEncodedPassword("mohit@123"));
//		Set<Role> userRoles=new HashSet<>();
//		userRoles.add(userRole);
//		user.setRole(userRoles);
//		userdao.save(user);
//		
		
		
		
	}
	public UserDetails registerNewUser(UserDetails user) {
        Role role = roleDao.findByRoleName("User");
        Set<Role> userRoles = new HashSet<>();
        userRoles.add(role);
        user.setRole(userRoles);
        user.setUserPassword(getEncodedPassword(user.getUserPassword()));

        return userdao.save(user);
    }
	
	 @Override
	    public UserDetails getUserByUserName(String userName) {
	        // Implement logic to get a user by username
		 return userdao.findByUserName(userName);
	    }

	    @Override
	    public List<UserDetails> getAllUsers() {
	        // Implement logic to retrieve all users
	    	
	    	 List<UserDetails> list=  userdao.findAll();
	    	
	    	 return list;
	    }
	
	public String getEncodedPassword(String password) {
        return passwordEncoder.encode(password);
    }

}
