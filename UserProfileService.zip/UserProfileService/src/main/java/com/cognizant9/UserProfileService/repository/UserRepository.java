/**
 * 
 */
package com.cognizant9.UserProfileService.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant9.UserProfileService.entity.UserDetails;

/**
 * @author mohit
 *
 */
@Repository
public interface UserRepository extends JpaRepository<UserDetails, Integer> {

	/**
	 * @param userName
	 * @return
	 */
	UserDetails findByUserName(String userName);

}
