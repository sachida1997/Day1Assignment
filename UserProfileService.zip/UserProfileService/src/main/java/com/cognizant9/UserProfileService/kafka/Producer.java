/**
 * 
 */
package com.cognizant9.UserProfileService.kafka;

import java.util.List;

import org.apache.kafka.common.protocol.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import com.cognizant9.UserProfileService.entity.UserDetails;

/**
 * @author mohit
 *
 */
@Service
public class Producer {
	@Value("${spring.kafka.topic-json.name}")
	private String topicJsonName;

	private static final Logger LOGGER = LoggerFactory.getLogger(Producer.class);

	private KafkaTemplate<String, UserDetails> kafkaTemplate;

	public Producer(KafkaTemplate<String, UserDetails> kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;
	}

	public void sendMessage(UserDetails data) {

		LOGGER.info(String.format("Message sent -> %s", data.toString()));

		org.springframework.messaging.Message<UserDetails> message = MessageBuilder.withPayload(data).setHeader(KafkaHeaders.TOPIC, topicJsonName)
				.build();

		kafkaTemplate.send(message);
	}}

