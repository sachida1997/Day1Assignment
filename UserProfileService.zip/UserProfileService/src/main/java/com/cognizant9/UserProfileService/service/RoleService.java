/**
 * 
 */
package com.cognizant9.UserProfileService.service;

import com.cognizant9.UserProfileService.entity.Role;

/**
 * @author mohit
 *
 */
public interface RoleService {
	public Role createNewRole(Role role);
}
