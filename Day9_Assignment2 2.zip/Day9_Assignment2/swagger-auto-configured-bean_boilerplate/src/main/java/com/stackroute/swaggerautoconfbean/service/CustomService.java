package com.stackroute.swaggerautoconfbean.service;

import org.springframework.stereotype.Service;

@Service
public interface CustomService {
    String customLogic();
}
