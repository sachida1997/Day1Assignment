package com.swaggerautoconfbean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.stackroute.swaggerautoconfbean.SwaggerAutoConfBeanApplication;

@SpringBootTest(classes = SwaggerAutoConfBeanApplication.class)
class SwaggerAutoConfBeanApplicationTests {

	@Test
	void contextLoads() {
	}

}
