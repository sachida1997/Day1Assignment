package com.stackroute;

import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;



@SpringBootApplication
@EnableRabbit
public class ProducerServiceApplication {

    /*
     * to host, username, password from application.yml
     */
	@Autowired
	private Environment env; 

    public static void main(String[] args) {
        SpringApplication.run(ProducerServiceApplication.class, args);
    }

    /*
    * Create a connection factory bean
    */
    @Bean
    ConnectionFactory connectionFactory() {
    	    CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
        	connectionFactory.setUsername(env.getProperty("spring.rabbitmq.username"));
        	connectionFactory.setPassword(env.getProperty("spring.rabbitmq.password"));
        	connectionFactory.setHost(env.getProperty("spring.rabbitmq.host"));
        	return connectionFactory;
    	}
    	
    

    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    /*
    * Define rabbitTemplate and setMessageConverter
     */
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
    	final RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
    	rabbitTemplate.setMessageConverter(jsonMessageConverter());
    	return rabbitTemplate;
    }
}
