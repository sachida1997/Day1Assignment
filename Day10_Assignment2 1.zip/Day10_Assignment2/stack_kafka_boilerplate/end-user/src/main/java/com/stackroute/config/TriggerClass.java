package com.stackroute.config;

import org.springframework.stereotype.Service;

@Service
public class TriggerClass {

    public String getMessageValue(String value) {
        return value;
    }

}