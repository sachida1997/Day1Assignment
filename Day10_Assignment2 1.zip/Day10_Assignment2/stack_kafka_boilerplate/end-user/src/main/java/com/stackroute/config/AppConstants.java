package com.stackroute.config;

public class AppConstants {

    public static final String LOCATION_UPDATE_TOPIC="location-update-topic";
    public static final String GROUP_ID="producer-1";
}
